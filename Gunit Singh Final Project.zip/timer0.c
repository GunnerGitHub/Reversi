/*
 * timer0.c
 *
 * Author: Peter Sutton
 *
 * We setup timer0 to generate an interrupt every 1ms
 * We update a global clock tick variable - whose value
 * can be retrieved using the get_clock_ticks() function.
 */

#include <avr/io.h>
#include <avr/interrupt.h>

#include <avr/pgmspace.h> // added
#include <stdio.h> // added
#include "serialio.h" //added
#include "terminalio.h" // added

#include "timer0.h"
////////////////Scoring #2///////////////////
#include "game.h"
volatile uint8_t seven_seg_cc = 0; //Added for scoring #2
uint8_t seven_seg_data[10] = {63,6,91,79,102,109,125,7,127,111};
volatile uint8_t digits_displayed = 1;
////////////////Scoring #2///////////////

uint8_t Paused = 0; ////// Pause Game

/////////////////// Turn Timing////////////////////////////
uint8_t TIMER = 0; 
uint32_t Time_elapsed = 0; 
uint32_t Starting_clock = 0; 
uint8_t Game_Running = 1;
////////////////// Turn Timing////////////////////////////

/* Our internal clock tick count - incremented every 
 * millisecond. Will overflow every ~49 days. */
static volatile uint32_t clockTicks;

/* Set up timer 0 to generate an interrupt every 1ms. 
 * We will divide the clock by 64 and count up to 124.
 * We will therefore get an interrupt every 64 x 125
 * clock cycles, i.e. every 1 milliseconds with an 8MHz
 * clock. 
 * The counter will be reset to 0 when it reaches it's
 * output compare value.
 */
void init_timer0(void) {
	/* Reset clock tick count. L indicates a long (32 bit) 
	 * constant. 
	 */
	clockTicks = 0L;
	
	/* Clear the timer */
	TCNT0 = 0;

	/* Set the output compare value to be 124 */
	OCR0A = 124;
	
	/* Set the timer to clear on compare match (CTC mode)
	 * and to divide the clock by 64. This starts the timer
	 * running.
	 */
	TCCR0A = (1<<WGM01);
	TCCR0B = (1<<CS01)|(1<<CS00);

	/* Enable an interrupt on output compare match. 
	 * Note that interrupts have to be enabled globally
	 * before the interrupts will fire.
	 */
	TIMSK0 |= (1<<OCIE0A);
	
	/* Make sure the interrupt flag is cleared by writing a 
	 * 1 to it.
	 */
	TIFR0 &= (1<<OCF0A);
	
	///////////////////Scoring #2////////////////////////
		DDRA = 0xFF;
		DDRC |= 0b00100000;
	///////////////////Scoring #2////////////////////////
}

uint32_t get_current_time(void) {
	uint32_t returnValue;

	/* Disable interrupts so we can be sure that the interrupt
	 * doesn't fire when we've copied just a couple of bytes
	 * of the value. Interrupts are re-enabled if they were
	 * enabled at the start.
	 */
	uint8_t interruptsOn = bit_is_set(SREG, SREG_I);
	cli();
	returnValue = clockTicks;
	if(interruptsOn) {
		sei();
	}
	return returnValue;
}

ISR(TIMER0_COMPA_vect) {
	/* Increment our clock tick count */
	if (!Paused) {
		clockTicks++;
	}

//////////////////Turn Timing////////////////////////////
if (TIMER){
	// Get time elapsed
	Time_elapsed = 31000 - (get_current_time() - Starting_clock);
	uint8_t turn_time = Time_elapsed/1000;
	//printf("%d", turn_time);
	
	if (timer_reset()==1){
		Starting_clock = get_current_time();
	}
	
	if (turn_time <= 0 || Game_Running==0){
		Game_Running = 0;
		timer_on();
	}
	
	seven_seg_cc = 1 ^ seven_seg_cc;
	PORTA = 0;
	/* Output the digit selection (CC) bit */
	if (seven_seg_cc){
		PORTC |= 0b00100000;
		} else {
		PORTC &= 0b11011111;
	}
	if(digits_displayed) {
		/* Display a digit */
		if(seven_seg_cc == 0) {
			/* Display rightmost digit - tenths of seconds */
			// Clearing port stops ghosting issues.
			//Port A
			
			PORTA = seven_seg_data[turn_time%10];
			} else {
			/* Display leftmost digit */
			if (turn_time < 10) {
				PORTA = 0;
				} else {
				//PORTA = 0;
				PORTA = seven_seg_data[(turn_time/10)%10];
			}
		}
		

		} else {
		/* No digits displayed -  display is blank */
		PORTA = 0;
	}
}
//////////////////Turn Timing////////////////////////////

//////////////////Scoring #2////////////////////////////
else{
	seven_seg_cc = 1 ^ seven_seg_cc;
	PORTA = 0;
			/* Output the digit selection (CC) bit */
			if (seven_seg_cc){
				PORTC |= 0b00100000;
				} else {
				PORTC &= 0b11011111;
			}
	if(digits_displayed) {
		/* Display a digit */
		if(seven_seg_cc == 0) {
			/* Display rightmost digit - tenths of seconds */
			// Clearing port stops ghosting issues.
			//Port A
			
			PORTA = seven_seg_data[get_score()%10];
		} else {
			/* Display leftmost digit */
			if (get_score() < 10) {
				PORTA = 0;
			} else {
				//PORTA = 0;
				PORTA = seven_seg_data[(get_score()/10)%10];
			}
		}
		

	} else {
		/* No digits displayed -  display is blank */
		PORTA = 0;
	}
}
		}
///////////////////Scoring #2////////////////////////////////////////


//////////////////Pause Game////////////////////////////////
void pause_game(void){Paused = 1;}
void unpause_game(void){Paused = 0;}
	
//////////////////Pause Game////////////////////////////////

//////////////////Turn Timing////////////////////////////////
void timer_on(void){
	TIMER ^= 1;
	Starting_clock = get_current_time();
}

uint8_t is_game_running(void){
	return Game_Running;
}

void set_game_running(uint8_t x){
	Game_Running = x;
}
//////////////////Turn Timing////////////////////////////////