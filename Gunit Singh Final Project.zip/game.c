/*
 * game.c
 *
 * Contains functions relating to the play of the game Reversi
 *
 * Author: Luke Kamols
 */ 

//////////////Following Added
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include "terminalio.h"
#include "timer0.h"
//////////////

#include "game.h"
#include "display.h"

#define CURSOR_X_START 5
#define CURSOR_Y_START 3

#define START_PIECES 2
static const uint8_t p1_start_pieces[START_PIECES][2] = { {3, 3}, {4, 4} };
static const uint8_t p2_start_pieces[START_PIECES][2] = { {3, 4}, {4, 3} };

uint8_t board[WIDTH][HEIGHT];
uint8_t cursor_x;
uint8_t cursor_y;
uint8_t cursor_visible;
uint8_t current_player;
uint8_t P1Score; //scoring 1
uint8_t P2Score; //scoring 1
uint8_t Turn_game_over = 0; //Piece #4
uint8_t restart_timer = 0; // turn timing


void initialise_board(void) {
	
	// initialise the display we are using
	initialise_display();
	
	// initialise the board to be all empty
	for (uint8_t x = 0; x < WIDTH; x++) {
		for (uint8_t y = 0; y < HEIGHT; y++) {
			board[x][y] = EMPTY_SQUARE;
		}
	}
	
	// now load in the starting pieces for player 1
	for (uint8_t i = 0; i < START_PIECES; i++) {
		uint8_t x = p1_start_pieces[i][0];
		uint8_t y = p1_start_pieces[i][1];
		board[x][y] = PLAYER_1; // place in array
		update_square_colour(x, y, PLAYER_1); // show on board
	}
	
	// and for player 2
	for (uint8_t i = 0; i < START_PIECES; i++) {
		uint8_t x = p2_start_pieces[i][0];
		uint8_t y = p2_start_pieces[i][1];
		board[x][y] = PLAYER_2;
		update_square_colour(x, y, PLAYER_2);		
	}
	
	// set the starting player
	current_player = PLAYER_1;
	
	// also set where the cursor starts
	cursor_x = CURSOR_X_START;
	cursor_y = CURSOR_Y_START;
	cursor_visible = 0;
	
	////////////////Scoring #1////////////////////
		P1Score = 2; //
		P2Score = 2; //
		move_terminal_cursor(10,10);
		printf("Red Score");
		move_terminal_cursor(22, 10);
		printf("%4d", P1Score);
		move_terminal_cursor(10,11);
		printf("Green Score");
		move_terminal_cursor(22, 11);
		printf("%4d", P2Score);
	//////////////////Scoring #1///////////////////
	
	get_turnLED(); ////LED Display
}

uint8_t get_piece_at(uint8_t x, uint8_t y) {
	// check the bounds, anything outside the bounds
	// will be considered empty
	if (x < 0 || x >= WIDTH || y < 0 || y >= WIDTH) {
		return EMPTY_SQUARE;
	} else {
		//if in the bounds, just index into the array
		return board[x][y];
	}
}

void flash_cursor(void) {
	
	if (cursor_visible) {
		// we need to flash the cursor off, it should be replaced by
		// the colour of the piece which is at that location
		uint8_t piece_at_cursor = get_piece_at(cursor_x, cursor_y);
		update_square_colour(cursor_x, cursor_y, piece_at_cursor);
		
	} else {
		// we need to flash the cursor on
		if (can_place() == 0){   ///Piece Placement #3
			update_square_colour(cursor_x, cursor_y, CURSOR_ill);  /////Piece Placement #3
		} else {
			update_square_colour(cursor_x, cursor_y, CURSOR);
		}
	}
	cursor_visible = 1 - cursor_visible; //alternate between 0 and 1
}

//check the header file game.h for a description of what this function should do
// (it may contain some hints as to how to move the pieces)

///////////////////////////Move Cursor/////////////////////////////////
void move_display_cursor(uint8_t dx, uint8_t dy) {
	//YOUR CODE HERE
		cursor_visible = 1;
		flash_cursor();
		cursor_x += dx;
		cursor_y += dy;
		//printf("%d \n", cursor_x);
		//printf("%d \n", cursor_y);
		if (cursor_x == 8){cursor_x=0;}
		if (cursor_x == 255){cursor_x=7;}
		if (cursor_y == 8){cursor_y=0;}
		if (cursor_y == 255){cursor_y=7;}
		flash_cursor();
	/*suggestions for implementation:
	 * 1: remove the display of the cursor at the current location
	 *		(and replace it with whatever piece is at that location)
	 * 2: update the positional knowledge of the cursor, this will include
	 *		variables cursor_x, cursor_y and cursor_visible
	 * 3: display the cursor at the new location
	 */
	
	
}

///////////////////////////Move Cursor/////////////////////////////////


uint8_t is_game_over(void) {
	// The game ends when every single square is filled
	// Check for any squares that are empty
	
	//////////////Turn Timing/////////////////
	if (is_game_running()==0){
		//printf_P(PSTR("Game OVERRRRRR"));
		if (current_player==PLAYER_1){
			P1Score = 0;
			P2Score = 64;
		}
		if (current_player==PLAYER_2){
			P1Score = 64;
			P2Score = 0;	
		}
		move_terminal_cursor(10,10);
		printf("Red Score");
		move_terminal_cursor(22, 10);
		printf("%4d", P1Score);
		move_terminal_cursor(10,11);
		printf("Green Score");
		move_terminal_cursor(22, 11);
		printf("%4d", P2Score);
		return 1;
	}
	//////////////Turn Timing/////////////////
	
	//////////////Piece #4/////////////////
	if (Turn_game_over==1){
		Turn_game_over = 0;
		get_turnLED();
		set_game_running(0); // turn timing
		return 1;
	}
	//////////////Piece #4/////////////////
	
	for (uint8_t x = 0; x < WIDTH; x++) {
		for (uint8_t y = 0; y < HEIGHT; y++) {
			if (board[x][y] == EMPTY_SQUARE) {
				// there was an empty square, game is not over
				return 0;
			}
		}
	}
	// every single position has been checked and no empty squares were found
	// the game is over
	set_game_running(0); // turn timing
	return 1;
}

///////////////////////Piece Placement 1//////////////////////
void piece_place1(void){
	update_square_colour(cursor_x, cursor_y, current_player);
	board[cursor_x][cursor_y] = current_player;
	if (current_player == PLAYER_1){current_player = PLAYER_2;}
	else if (current_player == PLAYER_2){current_player = PLAYER_1;}
	update_score(); // Scoring #1
	get_turnLED(); // LED Display
}
///////////////////////Piece Placement 1//////////////////////

///////////////////////Scoring #1/////////////////////////////
void update_score(void){
	P1Score = 0;
	P2Score = 0;
	for (uint8_t x = 0; x < WIDTH; x++) {
		for (uint8_t y = 0; y < HEIGHT; y++) {
			if (board[x][y] == PLAYER_1) {P1Score += 1;}
			if (board[x][y] == PLAYER_2) {P2Score += 1;}
		}
	}
	move_terminal_cursor(10,10);
	printf("Red Score");
	move_terminal_cursor(22, 10);
	printf("%4d", P1Score);
	move_terminal_cursor(10,11);
	printf("Green Score");
	move_terminal_cursor(22, 11);
	printf("%4d", P2Score);
}
///////////////////////Scoring #1/////////////////////////////

///////////////////////LED Display/////////////////////////////
void get_turnLED(void){
	DDRC |= 0xC0;
	if (current_player == PLAYER_1){PORTC|=0x40; PORTC &= 0x7F;}
	if (current_player == PLAYER_2){PORTC|=0x80; PORTC &= 0xBF;}
}
///////////////////////LED Display/////////////////////////////

///////////////////////Scoring #2/////////////////////////////
uint8_t get_score(){
	uint8_t display_score = 0;
	if (current_player == PLAYER_1){display_score = P1Score;}
	if (current_player == PLAYER_2){display_score = P2Score;}
	return display_score;
}
///////////////////////Scoring #2/////////////////////////////

//////////////////////Piece Placement #2+#3//////////////////////
void piece_place2(void){

	if (can_place()==1){
		/////////////PLAYER1//////////
		uint8_t x = cursor_x +1;
		uint8_t y = cursor_y;
		if (current_player==PLAYER_1){
			while (get_piece_at(x,y)==PLAYER_2 && x<WIDTH){x++;}// to the right
			if (get_piece_at(x,y)==PLAYER_1){
				while (x!=cursor_x){
					board[x][y] = PLAYER_1;
					update_square_colour(x, y, current_player);
					x--;
				}
			}
			
			x = cursor_x-1;
			y = cursor_y;
			
			while (get_piece_at(x,y)==PLAYER_2 && x>=0){x--;}// to the left
			if (get_piece_at(x,y)==PLAYER_1){
				while (x!=cursor_x){
					board[x][y] = PLAYER_1;
					update_square_colour(x, y, current_player);
					x++;
				}
			}
			
			x = cursor_x;
			y = cursor_y+1;
			
			while (get_piece_at(x,y)==PLAYER_2 && y<HEIGHT){y++;}// upwards
			if (get_piece_at(x,y)==PLAYER_1){
				while (y!=cursor_y){
					board[x][y] = PLAYER_1;
					update_square_colour(x, y, current_player);
					y--;
				}
			}
			
			x = cursor_x;
			y = cursor_y-1;
			
			while (get_piece_at(x,y)==PLAYER_2 && y>=0){y--;}// downwards
			if (get_piece_at(x,y)==PLAYER_1){
				while (y!=cursor_y){
					board[x][y] = PLAYER_1;
					update_square_colour(x, y, current_player);
					y++;
				}
			}
			
			x = cursor_x+1;
			y = cursor_y+1;
			while (get_piece_at(x,y)==PLAYER_2 && y<HEIGHT && x<WIDTH){y++;x++;}// right up diagnal
			if (get_piece_at(x,y)==PLAYER_1){
				while (y!=cursor_y && x!=cursor_x){
					board[x][y] = PLAYER_1;
					update_square_colour(x, y, current_player);
					y--; x--;
				}
			}
			
			x = cursor_x-1;
			y = cursor_y-1;
			while (get_piece_at(x,y)==PLAYER_2 && y>=0 && x>=0){y--;x--;}// left down diagnal
			if (get_piece_at(x,y)==PLAYER_1){
				while (y!=cursor_y && x!=cursor_x){
					board[x][y] = PLAYER_1;
					update_square_colour(x, y, current_player);
					y++; x++;
				}
			}

			x = cursor_x+1;
			y = cursor_y-1;
			while (get_piece_at(x,y)==PLAYER_2 && y>=0 && x<WIDTH){y--;x++;}// right down diagnal
			if (get_piece_at(x,y)==PLAYER_1){
				while (y!=cursor_y && x!=cursor_x){
					board[x][y] = PLAYER_1;
					update_square_colour(x, y, current_player);
					y++; x--;
				}
			}
			
			x = cursor_x-1;
			y = cursor_y+1;
			while (get_piece_at(x,y)==PLAYER_2 && y<HEIGHT && x>=0){y++;x--;}// left up diagonal
			if (get_piece_at(x,y)==PLAYER_1){
				while (y!=cursor_y && x!=cursor_x){
					board[x][y] = PLAYER_1;
					update_square_colour(x, y, current_player);
					y--; x++;
				}
			}

		}
		
		/////////////PLAYER2//////////
		if (current_player==PLAYER_2){
			x = cursor_x +1;
			y = cursor_y;
			while (get_piece_at(x,y)==PLAYER_1 && x<WIDTH){x++;}// to the right
			if (get_piece_at(x,y)==PLAYER_2){
				while (x!=cursor_x){
					board[x][y] = PLAYER_2;
					update_square_colour(x, y, current_player);
					x--;
				}
			}
			
			x = cursor_x-1;
			y = cursor_y;
			
			while (get_piece_at(x,y)==PLAYER_1 && x>=0){x--;}// to the left
			if (get_piece_at(x,y)==PLAYER_2){
				while (x!=cursor_x){
					board[x][y] = PLAYER_2;
					update_square_colour(x, y, current_player);
					x++;
				}
			}
			
			x = cursor_x;
			y = cursor_y+1;
			
			while (get_piece_at(x,y)==PLAYER_1 && y<HEIGHT){y++;}// upwards
			if (get_piece_at(x,y)==PLAYER_2){
				while (y!=cursor_y){
					board[x][y] = PLAYER_2;
					update_square_colour(x, y, current_player);
					y--;
				}
			}
			
			x = cursor_x;
			y = cursor_y-1;
			
			while (get_piece_at(x,y)==PLAYER_1 && y>=0){y--;}// downwards
			if (get_piece_at(x,y)==PLAYER_2){
				while (y!=cursor_y){
					board[x][y] = PLAYER_2;
					update_square_colour(x, y, current_player);
					y++;
				}
			}
			
			x = cursor_x+1;
			y = cursor_y+1;
			while (get_piece_at(x,y)==PLAYER_1 && y<HEIGHT && x<WIDTH){y++;x++;}// right up diagnal
			if (get_piece_at(x,y)==PLAYER_2){
				while (y!=cursor_y && x!=cursor_x){
					board[x][y] = PLAYER_2;
					update_square_colour(x, y, current_player);
					y--; x--;
				}
			}
			
			x = cursor_x-1;
			y = cursor_y-1;
			while (get_piece_at(x,y)==PLAYER_1 && y>=0 && x>=0){y--;x--;}// left down diagnal
			if (get_piece_at(x,y)==PLAYER_2){
				while (y!=cursor_y && x!=cursor_x){
					board[x][y] = PLAYER_2;
					update_square_colour(x, y, current_player);
					y++; x++;
				}
			}

			x = cursor_x+1;
			y = cursor_y-1;
			while (get_piece_at(x,y)==PLAYER_1 && y>=0 && x<WIDTH){y--;x++;}// right down diagnal
			if (get_piece_at(x,y)==PLAYER_2){
				while (y!=cursor_y && x!=cursor_x){
					board[x][y] = PLAYER_2;
					update_square_colour(x, y, current_player);
					y++; x--;
				}
			}
			
			x = cursor_x-1;
			y = cursor_y+1;
			while (get_piece_at(x,y)==PLAYER_1 && y<HEIGHT && x>=0){y++;x--;}// left up diagonal
			if (get_piece_at(x,y)==PLAYER_2){
				while (y!=cursor_y && x!=cursor_x){
					board[x][y] = PLAYER_2;
					update_square_colour(x, y, current_player);
					y--; x++;
				}
			}
		}
				///////Piece Place #1//////////
				update_square_colour(cursor_x, cursor_y, current_player);
				board[cursor_x][cursor_y] = current_player;
				if (current_player == PLAYER_1){current_player = PLAYER_2;}
				else if (current_player == PLAYER_2){current_player = PLAYER_1;}
				update_score(); // Scoring #1
				restart_timer =1; // Turn Timing
				pass_turn(); ///Piece #4
				get_turnLED(); // LED Display
	}
}
//////////////////////Piece Placement #2+#3///////////////////////


/////////////////////Piece Placement #3///////////////////////////
uint8_t can_place(void){

	if (board[cursor_x][cursor_y]== EMPTY_SQUARE){
		/////////////PLAYER1//////////
		uint8_t x = cursor_x +1;
		uint8_t y = cursor_y;

		if (current_player==PLAYER_1){
			if (get_piece_at(x,y)!=PLAYER_1){
			while (get_piece_at(x,y)==PLAYER_2 && x<WIDTH){x++;}// to the right
			if (get_piece_at(x,y)==PLAYER_1){return 1;}
			}
			
			x = cursor_x-1;
			y = cursor_y;
			
			if (get_piece_at(x,y)!=PLAYER_1){
			while (get_piece_at(x,y)==PLAYER_2 && x>=0){x--;}// to the left
			if (get_piece_at(x,y)==PLAYER_1){return 1;}
			}
			
			x = cursor_x;
			y = cursor_y+1;
			
			if (get_piece_at(x,y)!=PLAYER_1){
			while (get_piece_at(x,y)==PLAYER_2 && y<HEIGHT){y++;}// upwards
			if (get_piece_at(x,y)==PLAYER_1){return 1;}
			}
			
			x = cursor_x;
			y = cursor_y-1;
			
			if (get_piece_at(x,y)!=PLAYER_1){
			while (get_piece_at(x,y)==PLAYER_2 && y>=0){y--;}// downwards
			if (get_piece_at(x,y)==PLAYER_1){return 1;}
			}
			
			x = cursor_x+1;
			y = cursor_y+1;
			
			if (get_piece_at(x,y)!=PLAYER_1){
			while (get_piece_at(x,y)==PLAYER_2 && y<HEIGHT && x<WIDTH){y++;x++;}// right up diagnal
			if (get_piece_at(x,y)==PLAYER_1){return 1;}
			}
			
			x = cursor_x-1;
			y = cursor_y-1;
			
			if (get_piece_at(x,y)!=PLAYER_1){
			while (get_piece_at(x,y)==PLAYER_2 && y>=0 && x>=0){y--;x--;}// left down diagnal
			if (get_piece_at(x,y)==PLAYER_1){return 1;}
			}

			x = cursor_x+1;
			y = cursor_y-1;
			if (get_piece_at(x,y)!=PLAYER_1){
			while (get_piece_at(x,y)==PLAYER_2 && y>=0 && x<WIDTH){y--;x++;}// right down diagnal
			if (get_piece_at(x,y)==PLAYER_1){return 1;}
			}
			
			x = cursor_x-1;
			y = cursor_y+1;
			
			if (get_piece_at(x,y)!=PLAYER_1){
			while (get_piece_at(x,y)==PLAYER_2 && y<HEIGHT && x>=0){y++;x--;}// left up diagonal
			if (get_piece_at(x,y)==PLAYER_1){return 1;}
			}
			
		}
		
		/////////////PLAYER2//////////
		if (current_player==PLAYER_2){
			x = cursor_x +1;
			y = cursor_y;
			if (get_piece_at(x,y)!=PLAYER_2){
			while (get_piece_at(x,y)==PLAYER_1 && x<WIDTH){x++;}// to the right
			if (get_piece_at(x,y)==PLAYER_2){return 1;}
			}
			
			x = cursor_x-1;
			y = cursor_y;
			
			if (get_piece_at(x,y)!=PLAYER_2){
			while (get_piece_at(x,y)==PLAYER_1 && x>=0){x--;}// to the left
			if (get_piece_at(x,y)==PLAYER_2){return 1;}
			}
			
			x = cursor_x;
			y = cursor_y+1;
			
			if (get_piece_at(x,y)!=PLAYER_2){
			while (get_piece_at(x,y)==PLAYER_1 && y<HEIGHT){y++;}// upwards
			if (get_piece_at(x,y)==PLAYER_2){return 1;}
			}
			
			x = cursor_x;
			y = cursor_y-1;
			
			if (get_piece_at(x,y)!=PLAYER_2){
			while (get_piece_at(x,y)==PLAYER_1 && y>=0){y--;}// downwards
			if (get_piece_at(x,y)==PLAYER_2){return 1;}
			}
			
			x = cursor_x+1;
			y = cursor_y+1;
			
			if (get_piece_at(x,y)!=PLAYER_2){
			while (get_piece_at(x,y)==PLAYER_1 && y<HEIGHT && x<WIDTH){y++;x++;}// right up diagnal
			if (get_piece_at(x,y)==PLAYER_2){return 1;}
			}
			
			x = cursor_x-1;
			y = cursor_y-1;
			
			if (get_piece_at(x,y)!=PLAYER_2){
			while (get_piece_at(x,y)==PLAYER_1 && y>=0 && x>=0){y--;x--;}// left down diagnal
			if (get_piece_at(x,y)==PLAYER_2){return 1;}
			}

			x = cursor_x+1;
			y = cursor_y-1;
			if (get_piece_at(x,y)!=PLAYER_2){
			while (get_piece_at(x,y)==PLAYER_1 && y>=0 && x<WIDTH){y--;x++;}// right down diagnal
			if (get_piece_at(x,y)==PLAYER_2){return 1;}
			}
			
			x = cursor_x-1;
			y = cursor_y+1;
			
			if (get_piece_at(x,y)!=PLAYER_2){
			while (get_piece_at(x,y)==PLAYER_1 && y<HEIGHT && x>=0){y++;x--;}// left up diagonal
			if (get_piece_at(x,y)==PLAYER_2){return 1;}
			}
			
		}
	}
return 0;
}

//////////////////////Piece Placement #3///////////////////////////////////////////


//////////////////////Piece Placement #4///////////////////////////////////////////
void pass_turn(void){
	uint8_t x_cursor = cursor_x;
	uint8_t y_cursor = cursor_y;
	uint8_t turn_place = 0;
	uint8_t vari = 1;
	for (cursor_x = 0; cursor_x < WIDTH; cursor_x++) {
		for (cursor_y = 0; cursor_y < HEIGHT; cursor_y++) {
			if (can_place()==1){
				turn_place=1;
			}
		}
	}
	if (turn_place==0){
		if (current_player == PLAYER_1){current_player = PLAYER_2;}
		else if (current_player == PLAYER_2){current_player = PLAYER_1;}
	
	
	for (cursor_x = 0; cursor_x < WIDTH; cursor_x++) {
		for (cursor_y = 0; cursor_y < HEIGHT; cursor_y++) {
			if (can_place()==1){
				 vari = 0;
				 //Turn_game_over = 0;
				 
			}
		}
	}
		if (vari) {
			Turn_game_over = 1;
		}
	}
	
	cursor_x = x_cursor;
	cursor_y = y_cursor;
}
//////////////////////Piece Placement #4///////////////////////////////////////////


/////////////////////////////Turn Timing/////////////////////////////////
uint8_t timer_reset(void){
	uint8_t z = restart_timer;
	restart_timer = 0;
	return z;
}
/////////////////////////////Turn Timing/////////////////////////////////